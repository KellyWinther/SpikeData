"""Utilities for ordered replay analysis of behavior bouts vs SWRs.

Core definition used here
-------------------------
1. Spikes are filtered FIRST (optional KSLabel and neuron classification filters).
2. Remaining spikes are sorted by time.
3. Within each behavior bout / SWR, cluster IDs are reduced to UNIQUE cluster IDs
   in order of first spike.
4. Ordered replay is the longest common subsequence (LCS) of those two unique
   sequences. Because each sequence is unique, this is solved efficiently via
   a longest-increasing-subsequence (LIS) transform in O(k log k).
5. Replay percent uses the BEHAVIOR sequence as denominator:
       100 * matched_length / n_unique_behavior_clusters
   Thus behavior [1,2,3,4,5] vs SWR [1,1,2,3,4] -> unique SWR [1,2,3,4]
   -> matched [1,2,3,4] -> 80% replay.
"""

from __future__ import annotations
import ast
from bisect import bisect_left
from pathlib import Path
import numpy as np
import pandas as pd


def load_and_filter_spikes(
    spike_times_file: str,
    spike_clusters_file: str,
    kslabel_file: str | None = None,
    neuron_type_file: str | None = None,
    *,
    sampling_rate: float = 30000.0,
    filter_kslabel: bool = True,
    kslabels: tuple[str, ...] = ("good",),
    filter_neuron_type: bool = True,
    neuron_types: tuple[str, ...] = ("Pyramidal Neuron",),
) -> pd.DataFrame:
    """Load spikes, optionally filter them immediately, then sort by time.

    Set either filter toggle to False to disable that filter. ``neuron_types``
    may contain one or multiple labels, e.g. ("Pyramidal Neuron", "FSI").
    Labels are matched exactly to the Classification column.
    """
    times = np.load(spike_times_file).reshape(-1) / sampling_rate
    clusters = np.load(spike_clusters_file).reshape(-1)
    if len(times) != len(clusters):
        raise ValueError("spike_times and spike_clusters have different lengths")

    spike_df = pd.DataFrame({"Time": times, "Cluster ID": clusters.astype(int)})
    n_raw = len(spike_df)

    if filter_kslabel:
        if kslabel_file is None:
            raise ValueError("filter_kslabel=True requires kslabel_file")
        labels = pd.read_csv(kslabel_file, sep="\t").rename(columns={"cluster_id": "Cluster ID"})
        if "Cluster ID" not in labels or "KSLabel" not in labels:
            raise ValueError("KSLabel file must contain cluster_id/Cluster ID and KSLabel")
        keep = set(labels.loc[labels["KSLabel"].isin(kslabels), "Cluster ID"].astype(int))
        spike_df = spike_df[spike_df["Cluster ID"].isin(keep)]

    if filter_neuron_type:
        if neuron_type_file is None:
            raise ValueError("filter_neuron_type=True requires neuron_type_file")
        types = pd.read_csv(neuron_type_file)
        if "ClusterID" not in types or "Classification" not in types:
            raise ValueError("Neuron-type file must contain ClusterID and Classification")
        keep = set(types.loc[types["Classification"].isin(neuron_types), "ClusterID"].astype(int))
        spike_df = spike_df[spike_df["Cluster ID"].isin(keep)]

    # Explicit guarantee required for temporal sequence analysis.
    spike_df = spike_df.sort_values("Time", kind="mergesort").reset_index(drop=True)
    print(f"Spikes retained: {len(spike_df):,}/{n_raw:,} ({100*len(spike_df)/n_raw:.2f}%)")
    print(f"Clusters retained: {spike_df['Cluster ID'].nunique()}")
    return spike_df


def unique_preserving_order(seq) -> list[int]:
    """Return unique cluster IDs in order of first appearance."""
    seen = set()
    out = []
    for x in seq:
        x = int(x)
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def group_spikes_into_windows(
    window_df: pd.DataFrame,
    spike_df: pd.DataFrame,
    *,
    start_col: str = "Start",
    stop_col: str = "Stop",
    prefix: str = "Event",
    keep_all_spikes: bool = False,
) -> pd.DataFrame:
    """Assign sorted spikes to windows using np.searchsorted.

    Adds ``Unique {prefix} Cluster IDs``. If keep_all_spikes=True, also adds
    full spike-time and cluster-ID lists. No numeric sorting of cluster IDs is
    performed because that would destroy temporal firing order.
    """
    out = window_df.copy().reset_index(drop=True)
    times = spike_df["Time"].to_numpy(dtype=float)
    clusters = spike_df["Cluster ID"].to_numpy(dtype=int)

    unique_lists, time_lists, cluster_lists = [], [], []
    for start, stop in zip(out[start_col].to_numpy(float), out[stop_col].to_numpy(float)):
        left = np.searchsorted(times, start, side="left")
        right = np.searchsorted(times, stop, side="right")
        c = clusters[left:right].tolist()
        unique_lists.append(unique_preserving_order(c))
        if keep_all_spikes:
            time_lists.append(times[left:right].tolist())
            cluster_lists.append(c)

    out[f"Unique {prefix} Cluster IDs"] = unique_lists
    if keep_all_spikes:
        out[f"{prefix} Times"] = time_lists
        out[f"{prefix} Cluster IDs"] = cluster_lists
    return out


def prepare_behavior_windows(
    behavior_df: pd.DataFrame,
    *,
    event_types: tuple[str, ...] = ("social interaction", "cup interaction"),
    event_col: str = "EventType",
    start_col: str = "indexStart",
    stop_col: str = "indexEnd",
    index_sampling_rate: float = 2500.0,
) -> pd.DataFrame:
    """Filter BORIS behavior bouts and convert indexStart/indexEnd to seconds."""
    out = behavior_df.loc[behavior_df[event_col].isin(event_types)].copy()
    out["Start"] = pd.to_numeric(out[start_col]) / index_sampling_rate
    out["Stop"] = pd.to_numeric(out[stop_col]) / index_sampling_rate
    return out.reset_index(drop=True)


def ordered_unique_match(behavior_seq, swr_seq) -> list[int]:
    """Longest ordered common sequence for two unique-cluster sequences.

    Extra clusters may occur between matched clusters. The returned IDs preserve
    behavior/SWR relative order. Runs in O(k log k) after unique reduction.
    """
    b = unique_preserving_order(behavior_seq)
    s = unique_preserving_order(swr_seq)
    if not b or not s:
        return []

    pos = {cid: i for i, cid in enumerate(b)}
    common_ids = [cid for cid in s if cid in pos]
    positions = [pos[cid] for cid in common_ids]
    if not positions:
        return []

    tails = []
    tails_idx = []
    prev = [-1] * len(positions)
    for i, p in enumerate(positions):
        j = bisect_left(tails, p)
        if j == len(tails):
            tails.append(p)
            tails_idx.append(i)
        else:
            tails[j] = p
            tails_idx[j] = i
        if j > 0:
            prev[i] = tails_idx[j - 1]

    idx = tails_idx[-1]
    chosen = []
    while idx != -1:
        chosen.append(common_ids[idx])
        idx = prev[idx]
    return chosen[::-1]


def compare_behavior_to_swrs(
    behavior_grouped: pd.DataFrame,
    swr_grouped: pd.DataFrame,
    *,
    behavior_seq_col: str = "Unique Event Cluster IDs",
    swr_seq_col: str = "Unique Event Cluster IDs",
    behavior_label_col: str = "EventType",
) -> pd.DataFrame:
    """Return one row for every behavior-bout × SWR comparison."""
    rows = []
    for bi, brow in behavior_grouped.iterrows():
        bseq = unique_preserving_order(brow[behavior_seq_col])
        for si, srow in swr_grouped.iterrows():
            sseq = unique_preserving_order(srow[swr_seq_col])
            matched = ordered_unique_match(bseq, sseq)
            n_b = len(bseq)
            n_s = len(sseq)
            n_m = len(matched)
            rows.append({
                "Behavior Index": bi,
                "SWR Index": si,
                "Behavior Type": brow.get(behavior_label_col, None),
                "Behavior Start": brow.get("Start", np.nan),
                "Behavior Stop": brow.get("Stop", np.nan),
                "SWR Start": srow.get("Start", np.nan),
                "SWR Peak": srow.get("Peak", np.nan),
                "SWR Stop": srow.get("Stop", np.nan),
                "Unique Behavior Cluster IDs": bseq,
                "Unique SWR Cluster IDs": sseq,
                "Matched Ordered Cluster IDs": matched,
                "N Unique Behavior Clusters": n_b,
                "N Unique SWR Clusters": n_s,
                "N Matched Ordered Clusters": n_m,
                "Replay Percent of Behavior": (100.0 * n_m / n_b) if n_b else np.nan,
                "Matched Sequence Completeness Percent": 100.0 if n_m else 0.0,
            })
    return pd.DataFrame(rows)


def best_behavior_match_per_swr(pairwise_df: pd.DataFrame) -> pd.DataFrame:
    """For each SWR, retain the behavior bout with highest replay percentage."""
    if pairwise_df.empty:
        return pairwise_df.copy()
    idx = pairwise_df.groupby("SWR Index")["Replay Percent of Behavior"].idxmax()
    return pairwise_df.loc[idx].sort_values("SWR Index").reset_index(drop=True)


def save_histogram(values, output_file: str, *, bins=np.arange(0, 105, 5)):
    """Save histogram of replay percentages."""
    import matplotlib.pyplot as plt
    vals = pd.Series(values).dropna().astype(float)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.hist(vals, bins=bins, edgecolor="black")
    ax.set_xlabel("Percent of unique behavior sequence replayed")
    ax.set_ylabel("Number of SWRs")
    ax.set_xlim(0, 100)
    fig.tight_layout()
    fig.savefig(output_file, dpi=300)
    plt.close(fig)


def lists_to_csv_safe(df: pd.DataFrame) -> pd.DataFrame:
    """Copy dataframe and serialize list columns cleanly for CSV output."""
    out = df.copy()
    for col in out.columns:
        if out[col].dtype == object:
            out[col] = out[col].apply(lambda x: repr(x) if isinstance(x, list) else x)
    return out
