"""Example end-to-end behavior-to-SWR replay analysis.
Edit CONFIG below, then run: python run_replay_analysis.py
"""
from pathlib import Path
import pandas as pd
from replay_utils import (
    load_and_filter_spikes, prepare_behavior_windows, group_spikes_into_windows,
    compare_behavior_to_swrs, best_behavior_match_per_swr, save_histogram,
    lists_to_csv_safe,
)

CONFIG = {
    # Required input files
    "spike_times": "spike_times.npy",
    "spike_clusters": "spike_clusters.npy",
    "kslabels": "cluster_KSLabel.tsv",
    "neuron_types": "cluster_type.csv",
    "behavior_csv": "events_with_indices.csv",
    "swr_csv": "SWRs_ca2_labeled.csv",

    # Filtering: turn either filter on/off independently.
    "filter_kslabel": True,
    "kslabels_to_keep": ("good",),
    "filter_neuron_type": True,
    # Actual labels in your cluster_type.csv include:
    # "Pyramidal Neuron", "FSI", "Other", "Non-somatic"
    "neuron_types_to_keep": ("Pyramidal Neuron",),

    # Behavior types to compare against SWRs
    "behavior_types": ("social interaction", "cup interaction"),

    # Sampling rates
    "spike_sampling_rate": 30000.0,
    "behavior_index_sampling_rate": 2500.0,

    # False is recommended for large data: only unique ordered IDs are retained.
    "keep_all_spikes_in_windows": False,

    "output_dir": "replay_results",
}


def main():
    outdir = Path(CONFIG["output_dir"])
    outdir.mkdir(parents=True, exist_ok=True)

    # 1) Load + FILTER FIRST + sort chronologically.
    spikes = load_and_filter_spikes(
        CONFIG["spike_times"], CONFIG["spike_clusters"],
        kslabel_file=CONFIG["kslabels"],
        neuron_type_file=CONFIG["neuron_types"],
        sampling_rate=CONFIG["spike_sampling_rate"],
        filter_kslabel=CONFIG["filter_kslabel"],
        kslabels=CONFIG["kslabels_to_keep"],
        filter_neuron_type=CONFIG["filter_neuron_type"],
        neuron_types=CONFIG["neuron_types_to_keep"],
    )

    # 2) Load behavior and SWR windows.
    behavior_raw = pd.read_csv(CONFIG["behavior_csv"])
    behavior = prepare_behavior_windows(
        behavior_raw,
        event_types=CONFIG["behavior_types"],
        index_sampling_rate=CONFIG["behavior_index_sampling_rate"],
    )
    swrs = pd.read_csv(CONFIG["swr_csv"])

    # 3) Assign the already-filtered spikes to behavior bouts and SWRs.
    behavior_grouped = group_spikes_into_windows(
        behavior, spikes, prefix="Event",
        keep_all_spikes=CONFIG["keep_all_spikes_in_windows"],
    )
    swr_grouped = group_spikes_into_windows(
        swrs, spikes, prefix="Event",
        keep_all_spikes=CONFIG["keep_all_spikes_in_windows"],
    )

    # 4) Ordered comparison. Extra/interspersed spikes are allowed.
    pairwise = compare_behavior_to_swrs(behavior_grouped, swr_grouped)

    # 5) One histogram point per SWR = its highest behavior-bout replay %.
    best = best_behavior_match_per_swr(pairwise)

    lists_to_csv_safe(behavior_grouped).to_csv(outdir / "behavior_unique_clusters.csv", index=False)
    lists_to_csv_safe(swr_grouped).to_csv(outdir / "swr_unique_clusters.csv", index=False)
    lists_to_csv_safe(pairwise).to_csv(outdir / "behavior_swr_pairwise_replay.csv", index=False)
    lists_to_csv_safe(best).to_csv(outdir / "best_replay_per_swr.csv", index=False)
    save_histogram(best["Replay Percent of Behavior"], outdir / "replay_percent_histogram.png")

    print(f"Saved results to: {outdir.resolve()}")


if __name__ == "__main__":
    main()
